x = int(input("kolik ti je let: "))
if x > 17:
    print("Zletilý")
else:
    if x < 15:
        print("Nezletilý")
    else:
        print("Mladistvý")
